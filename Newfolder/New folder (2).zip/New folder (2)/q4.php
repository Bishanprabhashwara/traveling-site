<html>
 <body>
 <?php
 echo "<h1>Student Details</h1><br><br>";
 $name="Henry";
 $age=24;
 $uni="Harvard";
 ?>
 <table border="1">
	<tr>
		<th>Name</th>
		<th>Age</th>
		<th>University</th>
	</tr>
	<tr>
		<td>
			<?php echo $name;?>
		</td>
		<td>
			<?php echo $age;?>
		</td>
		<td>
			<?php  echo $uni;?>
		</td>
	</tr>
 </table>

	 
 </body>
</html>
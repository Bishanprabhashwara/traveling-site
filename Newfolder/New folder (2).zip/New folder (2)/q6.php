<html>
 <body>
 <?php
 $num1=0;
 
 for($i=0;$i<100;$i=$i+1)
 {
	 $num1=$num1+$i;
 }
 echo "total $num1";
 ?> 	 
 </body>
</html>
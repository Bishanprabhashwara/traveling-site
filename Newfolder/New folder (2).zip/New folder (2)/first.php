<html>
 <body>
<?php
 echo "My first PHP program"; 
 ?>
 </body>
</html>